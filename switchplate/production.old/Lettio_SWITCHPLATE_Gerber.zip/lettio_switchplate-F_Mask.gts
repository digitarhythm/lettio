G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.8*
G04 #@! TF.CreationDate,2026-07-23T00:15:24+09:00*
G04 #@! TF.ProjectId,lettio_switchplate,6c657474-696f-45f7-9377-69746368706c,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.8) date 2026-07-23 00:15:24*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
